import { useState, useEffect } from "react";
import type { FC } from "react";
import { clsx } from "@heroui/shared-utils";

// 使用 Heroicons 作为图标
import {
  PauseIcon,
  PlayIcon,
  ForwardIcon,
  BackwardIcon,
  ArrowPathIcon,
  ArrowsRightLeftIcon,
  SpeakerWaveIcon,
  SpeakerXMarkIcon,
} from "@heroicons/react/24/solid";
import { HeartIcon as HeartOutlineIcon } from "@heroicons/react/24/outline";
import { HeartIcon as HeartSolidIcon } from "@heroicons/react/24/solid";

export interface MusicPlayerProps {
  className?: string;
}

// 模拟歌词数据
const mockLyrics = [
  { time: 0, text: "当阳光洒满大地" },
  { time: 3, text: "当微风轻抚脸庞" },
  { time: 6, text: "我在这里等待着你" },
  { time: 9, text: "等待那美好的时光" },
  { time: 12, text: "让我们一起前行" },
  { time: 15, text: "在音乐的世界里徜徉" },
];

export const MusicPlayer: FC<MusicPlayerProps> = ({ className, ...otherProps }) => {
  const [liked, setLiked] = useState(false);
  const [isPlaying, setIsPlaying] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration] = useState(240); // 4分钟
  const [currentLyricIndex, setCurrentLyricIndex] = useState(0);

  // 模拟播放进度
  useEffect(() => {
    if (isPlaying) {
      const interval = setInterval(() => {
        setCurrentTime(prev => {
          const newTime = prev + 1;
          if (newTime >= duration) {
            setIsPlaying(false);
            setCurrentTime(0);
            return 0;
          }
          return newTime;
        });
      }, 1000);
      return () => clearInterval(interval);
    }
  }, [isPlaying, duration]);

  // 更新歌词显示
  useEffect(() => {
    const index = mockLyrics.findIndex(lyric => lyric.time > currentTime);
    if (index === -1) {
      setCurrentLyricIndex(mockLyrics.length - 1);
    } else {
      setCurrentLyricIndex(Math.max(0, index - 1));
    }
  }, [currentTime]);

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const handleProgressClick = (e: React.MouseEvent<HTMLDivElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const clickX = e.clientX - rect.left;
    const percentage = clickX / rect.width;
    const newTime = Math.floor(percentage * duration);
    setCurrentTime(newTime);
  };

  return (
    <div
      className={clsx(
        "music-player-glass",
        "w-full max-w-sm mx-auto",
        "bg-gradient-to-br from-white/10 to-white/5",
        "backdrop-blur-3xl",
        "border border-white/20",
        "rounded-3xl",
        "shadow-2xl",
        "overflow-hidden",
        "transition-all duration-500 ease-out",
        "hover:shadow-3xl hover:scale-[1.02]",
        "group",
        className
      )}
      {...otherProps}
    >
      {/* 背景光效 */}
      <div className="absolute inset-0 bg-gradient-to-br from-purple-500/10 via-transparent to-blue-500/10 opacity-0 group-hover:opacity-100 transition-opacity duration-700" />
      
      {/* 顶部装饰条 */}
      <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-purple-400 via-pink-400 to-blue-400 opacity-60" />
      
      <div className="relative z-10 p-6">
        {/* 专辑封面区域 */}
        <div className="flex justify-center mb-6">
          <div className="relative group">
            <div className="w-32 h-32 rounded-2xl overflow-hidden shadow-2xl group-hover:shadow-3xl transition-all duration-500">
              <img
                src="https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?w=400&h=400&fit=crop&crop=center"
                alt="Album Cover"
                className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
              />
            </div>
            {/* 播放状态指示器 */}
            <div className={clsx(
              "absolute inset-0 bg-black/40 rounded-2xl",
              "flex items-center justify-center",
              "transition-all duration-300",
              isPlaying ? "opacity-100" : "opacity-0"
            )}>
              <div className="w-12 h-12 bg-white/90 rounded-full flex items-center justify-center">
                <PauseIcon className="w-6 h-6 text-gray-800" />
              </div>
            </div>
          </div>
        </div>

        {/* 音乐信息 */}
        <div className="text-center mb-6">
          <h3 className="text-lg font-semibold text-white/95 mb-1 tracking-tight">
            Frontend Radio
          </h3>
          <p className="text-sm text-white/70 mb-2">Daily Mix • 12 Tracks</p>
          
          {/* 歌词显示 */}
          <div className="h-8 flex items-center justify-center overflow-hidden">
            <div className="text-sm text-white/80 font-medium transition-all duration-500">
              {mockLyrics[currentLyricIndex]?.text || "享受音乐的美好时光"}
            </div>
          </div>
        </div>

        {/* 进度条 */}
        <div className="mb-6">
          <div
            className="w-full h-1.5 bg-white/20 rounded-full cursor-pointer relative overflow-hidden"
            onClick={handleProgressClick}
          >
            <div className="absolute inset-0 bg-gradient-to-r from-purple-400 to-blue-400 rounded-full transition-all duration-300" />
            <div
              className="absolute inset-0 bg-white/80 rounded-full transition-all duration-300"
              style={{ width: `${(currentTime / duration) * 100}%` }}
            />
            {/* 进度指示器 */}
            <div
              className="absolute top-1/2 w-3 h-3 bg-white rounded-full shadow-lg transition-all duration-300 transform -translate-y-1/2"
              style={{ left: `${(currentTime / duration) * 100}%` }}
            />
          </div>
          <div className="flex justify-between text-xs text-white/60 mt-2">
            <span>{formatTime(currentTime)}</span>
            <span>{formatTime(duration)}</span>
          </div>
        </div>

        {/* 控制按钮 */}
        <div className="flex items-center justify-center gap-4 mb-6">
          <button
            className={clsx(
              "p-2 rounded-full transition-all duration-300",
              "hover:bg-white/10 active:scale-95",
              "text-white/70 hover:text-white/90"
            )}
            onClick={() => setIsMuted(!isMuted)}
          >
            {isMuted ? (
              <SpeakerXMarkIcon className="w-5 h-5" />
            ) : (
              <SpeakerWaveIcon className="w-5 h-5" />
            )}
          </button>
          
          <button
            className={clsx(
              "p-2 rounded-full transition-all duration-300",
              "hover:bg-white/10 active:scale-95",
              "text-white/70 hover:text-white/90"
            )}
          >
            <ArrowPathIcon className="w-5 h-5" />
          </button>
          
          <button
            className={clsx(
              "p-2 rounded-full transition-all duration-300",
              "hover:bg-white/10 active:scale-95",
              "text-white/70 hover:text-white/90"
            )}
          >
            <BackwardIcon className="w-5 h-5" />
          </button>
          
          {/* 播放/暂停按钮 */}
          <button
            className={clsx(
              "w-14 h-14 rounded-full transition-all duration-300",
              "bg-gradient-to-r from-purple-500 to-blue-500",
              "hover:from-purple-600 hover:to-blue-600",
              "active:scale-95 shadow-lg hover:shadow-xl",
              "flex items-center justify-center"
            )}
            onClick={() => setIsPlaying(!isPlaying)}
          >
            {isPlaying ? (
              <PauseIcon className="w-7 h-7 text-white" />
            ) : (
              <PlayIcon className="w-7 h-7 text-white ml-1" />
            )}
          </button>
          
          <button
            className={clsx(
              "p-2 rounded-full transition-all duration-300",
              "hover:bg-white/10 active:scale-95",
              "text-white/70 hover:text-white/90"
            )}
          >
            <ForwardIcon className="w-5 h-5" />
          </button>
          
          <button
            className={clsx(
              "p-2 rounded-full transition-all duration-300",
              "hover:bg-white/10 active:scale-95",
              "text-white/70 hover:text-white/90"
            )}
          >
            <ArrowsRightLeftIcon className="w-5 h-5" />
          </button>
        </div>

        {/* 底部操作栏 */}
        <div className="flex items-center justify-between">
          <button
            className={clsx(
              "p-2 rounded-full transition-all duration-300",
              "hover:bg-white/10 active:scale-95",
              "text-white/70 hover:text-white/90"
            )}
            onClick={() => setLiked(!liked)}
          >
            {liked ? (
              <HeartSolidIcon className="w-5 h-5 text-red-400" />
            ) : (
              <HeartOutlineIcon className="w-5 h-5" />
            )}
          </button>
          
          <div className="text-xs text-white/50">
            <span>音质: 320kbps</span>
          </div>
        </div>
      </div>
    </div>
  );
};
